#ifndef ZONE_H
#define ZONE_H
#include <string>
class zone
{

public:
    std::string type;
    zone();
    
};

#endif