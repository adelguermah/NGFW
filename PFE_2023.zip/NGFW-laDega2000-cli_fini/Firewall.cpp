#include <string>
#include <vector>
#include "Policy.h"
#include "tabses.h"
#include "Securite_Context.h"
#include "filtrage.h"
#include "filtrurl.h"
#include "tabdomain.h"
#include "interfaces.h"
#include "Routage_Context.h"
#include "routage_stat.h"
#include "nat.h"
#include "configuration.h"
#include "inter_conf.h"
#include "url_conf.h"
#include "zone_conf.h"
#include "base.h"
#include "session_conf.h"
#include "groupe.h"
#include "route_conf.h"
#include <thread>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <functional>
#include <iterator>
#include "nat_conf.h"
#include <boost/program_options.hpp>
#include "crow_all.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <fstream>
#include <streambuf>
#include <sstream>
#include "in_conf.h"
#include "user_conf.h"
#include <iostream>

using namespace std;
using namespace crow;
namespace po = boost::program_options;


class Firewall
{

private:
    Firewall& operator=(const Firewall&) = delete;
    Firewall(const Firewall&) = delete;
    // Private constructor
    Firewall() {
        
        j = new configuration;
        u_conf = new user_conf;
        z_conf = new zone_conf;
        a_conf = new url_conf;
        s_conf = new session_conf;
        r_conf = new route_conf;
        n_conf = new nat_conf;
        i_conf = new in_conf;
    }


public:
    inter_conf* j;
    inter_conf* u_conf;
    inter_conf* z_conf;
    inter_conf* a_conf;
    inter_conf* s_conf;
    inter_conf* r_conf;
    inter_conf* n_conf;
    inter_conf* i_conf;
    tabses s;
    tabdomain tab;
    std::thread packet_filter_thread_;
    bool running = true;

    
    Firewall(Firewall&&) = delete;
    
    Firewall& operator=(Firewall&&) = delete;



    void display_loading_message(std::string message) {
    const int total_width =100;
    std::cout <<"Loading "<< message << std::endl;

    for (int i = 0; i <= total_width; i++) {
        float progress = static_cast<float>(i) / total_width;

        std::cout << "\r\033[48;5;34m"; // Set background color to blue
        for (int j = 0; j < i; j++) {
            std::cout << " ";
        }
        std::cout << "\033[0m"; // Reset color to default
        for (int j = i; j < total_width; j++) {
            std::cout << " ";
        }
        std::cout << "] " << static_cast<int>(progress * 100) << "% complete" << std::flush;

        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    std::cout<<std::endl;

    //std::cout << "\nLoading "<<message<<" complete!" << std::endl;
}


     static Firewall& getInstance() {
        static Firewall instance_;
        return instance_;
    }

   /* Firewall(int argc, char *argv[]) {
      j=new configuration;
     u_conf=new user_conf;
     z_conf=new zone_conf;
     a_conf=new url_conf;
     s_conf=new session_conf;
     r_conf=new route_conf;
     n_conf=new nat_conf;
      //this->j->add("dega");

    /*  packet_filter_thread_ = std::thread([this]() {
       get_packet();
    });*/
   // display_loading_message("modules of NGFW...");

   /* display_loading_message(" modules of network...");

    display_loading_message(" modules of configuration...");

    std::cout<<std::endl<<"Loading of all modules complete ... \n \n \n ";
    // Your CLI code here
    }*/
   


   
   




    void addd_policy(base b){     // tu lui donne nom de la policy a ajouter et elle ajoute
           
        j->add(b.name_policy);
    }


 void add_policy(const std::vector<std::string>& params) {
    if (params.size() == 1) {
        std::string name = params[0];
      base  b;
      b.name_policy=params[0];
      this->addd_policy(b);
        // Use the variable to perform the required action
        std::cout << "Adding policy with name: " << name << std::endl;cout<<endl;

    } else {
        std::cout << "Invalid number of parameters for add_policy command." << std::endl;
        std::cout << "Expected usage: add_policy name" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  name: The policy name to be added" << std::endl;
    }
}











 

 




void show_all_policy(const std::vector<std::string>& params) {
    
        show_policy();
    
}










// show_policy


    base get_policy(base b){    // elle retourne la policy corespendant au nom que ta donner
      b=j->get(b.name_policy,b);
      return b;
    }

   void show_policy(){
      base b;
     // b=j->get_all(b);

      for(Policy pp: j->get_all(b).polit){
      
        cout<<pp.name<<endl;
        for(Rule r : pp.rules){
          cout<<r.src_zo<<" "<<r.dst_zo<<" "<<r.srcIP<<" "<<r.destIP<<" "<< r.srcPort<<" " << r.destPort<<" "<<r.us.name<<" "<<r.permit<<endl;
        }cout<<endl;
      }
    }


  // add_rule_in_policy
void add_rule_in_policy(const std::vector<std::string>& params) {
    if (params.size() == 9) {
        std::string rule_name = params[0];
        base b;
        b.rul.src_zo=params[1];
        b.rul.dst_zo=params[2];
        b.rul.srcIP=params[3];
        b.rul.destIP=params[4];
        b.rul.srcPort=std::stoi(params[5]);
        b.rul.destPort=std::stoi(params[6]);
        b.rul.us.name=params[7];
        if(params[8]=="true")
        {
          b.rul.permit=true;
        }else if(params[8]=="false")b.rul.permit=false;
        
        
        
        
        b.name_policy=params[0];
        add_rule(b);
        // Use the rule_name variable to perform the required action
        std::cout << "Adding rule "<< " in policy :" <<params[0]<< std::endl<<endl;

    } else {
        std::cout << "Invalid number of parameters for add_rule_in_policy command." << std::endl;
        std::cout << "Expected usage: add_rule_in_policy policyName sourceZone destinationZone sourceIp destinationIp sourcePort destinationPort userName action" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  policyName: The name of the policy to which the rule will be added." << std::endl;
        std::cout << "  sourceZone: The name of the source zone for the rule." << std::endl;
        std::cout << "  destinationZone: The name of the destination zone for the rule." << std::endl;
        std::cout << "  sourceIp: The source IP address for the rule." << std::endl;
        std::cout << "  destinationIp: The destination IP address for the rule." << std::endl;
        std::cout << "  sourcePort: The source port for the rule." << std::endl;
        std::cout << "  destinationPort: The destination port for the rule." << std::endl;
        std::cout << "  userName: The name of the user associated with the rule." << std::endl;
        std::cout << "  action: The action to be taken for the rule (ACCEPT or DROP)." << std::endl;

    }
}




    void add_rule(base b){ // tu dois donne un objet base avec dedant une rule et un b.name_policy
      j->update(b,b.name_policy);
    }

    void get_rule(){

      
    }

    void add_user_groupe(base b){    // tu lui donne nom du groupe a ajouter 
      u_conf->add(b.user_groupe_name);
    }


    void addgroupe(const std::vector<std::string>& params) {
    if (params.size() == 1) {
        string g_name = (params[0]);
        base b;
        b.user_groupe_name=g_name;
        add_user_groupe(b);

      

    } else {
        std::cout << "Invalid number of parameters for addUser command." << std::endl;
        std::cout << "Expected usage: add_groupe groupname " << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  groupname: The name of group  " << std::endl;
       
    }
}









 void addgroupeint(const std::string grp) {
        string g_name = grp;
        base b;
        b.user_groupe_name=g_name;
        add_user_groupe(b);

}








    void get_user(base b){   // tu lui donne non de user et elle retourne objet base avec interieur objet user
      u_conf->get(b.user_name,b);
    }



    void addUser(const std::vector<std::string>& params) {
    if (params.size() == 2) {
        string g_name = (params[0]);
        string u_name = params[1];
        add_user_in_group(u_name,g_name);
     
    } else {
        std::cout << "Invalid number of parameters for addUser command." << std::endl;
        std::cout << "Expected usage: add_user group name " << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  group: The group of user " << std::endl;
        std::cout << "  name: The user name" << std::endl;
        
    }
}




void addUserint(const std::string u_name,const std::string g_name) {
    
        add_user_in_group(u_name,g_name);
     
   
     
    
}





    void add_user_in_group(string u_name,string g_name){
      base b;
      b.user_groupe_name=g_name;
      b.user_name=u_name;
      u_conf->update(b,b.user_groupe_name);
    }
 

//const std::vector<std::string>& params
    void showUser() {
      get_all_user(false);
      }


       void showgroupe(const std::vector<std::string>& params) {
      get_all_user(true);
    }
   



   std::string get_all_groups(){
        base b;
        std::ostringstream output_stream;
        for(groupe po : u_conf->get_all(b).tab_groupe){
            output_stream<<po.name<<" ";
          }
         return output_stream.str();
    }





    void get_all_user(bool type){
        base b;
       //b= u_conf->get_all(b);
         if(type==false){
            for(user ub : u_conf->get_all(b).tab_use)
            {   if(!ub.group.empty() && ! ub.name.empty()){
                cout<<ub.name <<" "<<ub.group<<endl;}
                
            }
         }else{
          for(groupe po : u_conf->get_all(b).tab_groupe){
            cout<<po.name<<endl;
          }
         }
    }


/* void showGroup(const std::vector<std::string>& params)  {
      base::printUserGroupNames();
      }*/

 














void addInterface(const std::vector<std::string>& params) {
    if (params.size() == 4) {
        //int id = std::stoi(params[0]);
        std::string file = params[0];
        std::string out = params[1];
        std::string ip = params[2];
        std::string zone = params[3];
        const char* file2=params[0].c_str();
        const char* out2=params[1].c_str();

        // Use the variables to perform the required action
       // std::cout << "Adding interfaces: " <<ip<<endl;
        interfaces i(file2,out2,ip,zone);
        add_interface(i);cout<<endl;

    } else {
        std::cout << "Invalid number of parameters for addInterface command." << std::endl;
        std::cout << "Expected usage: addInterface id base inter_conf tools zone" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  id: The interface ID (integer)" << std::endl;
        std::cout << "  base: The base configuration" << std::endl;
        std::cout << "  inter_conf: The interface configuration" << std::endl;
        std::cout << "  tools: The tools used for the interface" << std::endl;
        std::cout << "  zone: The zone of the interface" << std::endl;
    }
}


/*
    void add_interface(interfaces i){
        base bii;
       // bi.interf=i;
        bii.tab_interfaces.push_back(i);
        //i_conf->update(bi,"rien");
    }
*/

    void get_interface(){
     /* base bi;
      char*e ="eeee";
        bi=i_conf->get_all(bi);
        for(interfaces f : bi.tab_interfaces){
          cout<<f.output<<" "<<f.ip_adr<<f.zon.type<<" "<<f.file_name<<"   "<<e<<endl;
        }*/
        std::vector<interfaces>& all_ifaces = interfaces::getAllInterfaces();

        for(interfaces f : all_ifaces){
          cout<<f.output<<" "<<f.ip_adr<<"  "<<f.zon.type<<" "<<endl;
        }cout<<endl;
    }


    std::string get_all_interface(){
    std::ostringstream output_stream;

         std::vector<interfaces>& all_ifaces = interfaces::getAllInterfaces();

        for(interfaces f : all_ifaces){
          output_stream<<f.ip_adr<<" "<<f.zon.type<<" ";
        }
        return output_stream.str();
    }



     void add_interface(interfaces i){
        base bi;
        bi.interf=i;
        i_conf->update(bi,"rien");
    }

    void showInterface(const std::vector<std::string>& params) {
       // int id = std::stoi(params[0]);

        // Use the variable to perform the required action
        std::cout << "Showing interfaces " << std::endl;
        get_interface();

    
    
}

























    void addZone(const std::vector<std::string>& params) {
    if (params.size() == 1) {
      
        std::string type = params[0];

        // Use the variables to perform the required action
        std::cout << "Adding zone with name:" << type << std::endl;
        base bo;
        bo.zone_name=type;
        add_zone(bo);
    } else {
        std::cout << "Invalid number of parameters for addZone command." << std::endl;
        std::cout << "Expected usage: add_zone name" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  name: The name of zone " << std::endl;
    }
}





    void add_zone(base bo){   // tu lui donne le type de la zone a ajouter
      z_conf->add(bo.zone_name);
    }


    void showZone(const std::vector<std::string>& params) {
        get_zone();
        }



    base get_zone(){    // tu lui donne le nom(type) de la zone et il te retourne un objet zone dans base
      base bbbb;
      bbbb=z_conf->get_all(bbbb);
      
    for (zone z : bbbb.zii) {
        if (!z.type.empty()) {
        cout << z.type << endl;
    }
}

     /* std::vector<zone>& all_ifaces = zone::getAllZones();

        for(zone z : all_ifaces){
          cout<<z.type<<endl;
        }*/

    }






    void addroute(const std::vector<std::string>& params) {
    if (params.size() == 2) {
        //int id = std::stoi(params[0]);
        std::string publicIp = params[0];
        std::string privateIp = params[1];
        base br;
        br.r_statique.adr_dest=publicIp;
        br.r_statique.next_hop=privateIp;
        // Use the variables to perform the required action
        std::cout << "Adding route  "  << ", destinationIp: " << publicIp << ", next_hop: " << privateIp << std::endl;
        add_route(br);cout<<endl<<endl;
    } else {
        std::cout << "Invalid number of parameters for addroute command." << std::endl;
        std::cout << "Expected usage: add_route destnationIP nexthop" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  destionationIP: The public IP address" << std::endl;
        std::cout << "  nexthop: The private IP address" << std::endl;
    }
}













    void add_route(base b){
      r_conf->update(b,"rien");
    }

    void get_route(){
      base brr;
        
        for(tab_stat rt : r_conf->get_all(brr).tab_r_statique){
            cout<<rt.adr_dest<<" "<<rt.next_hop<<endl;
        }cout<<endl<<endl;
    }





    void show_route(const std::vector<std::string>& params) {
    
        //int id = std::stoi(params[0]);

        // Use the variable to perform the required action
        std::cout << "Showing route "<< std::endl;
        get_route();
    }





    void addNat(const std::vector<std::string>& params) {
    if (params.size() == 2) {
        //int id = std::stoi(params[0]);
        std::string publicIp = params[0];
        std::string privateIp = params[1];

        // Use the variables to perform the required action
        std::cout << "Adding NAT " << ", publicIp: " << publicIp << ", privateIp: " << privateIp << std::endl;
        base bn;
        bn.n_statique.ip_public=publicIp;
        bn.n_statique.ip_prive=privateIp;
        add_nat(bn);  
    } else {
        std::cout << "Invalid number of parameters for addNat command." << std::endl;
        std::cout << "Expected usage: add_Nat  publicIp privateIp" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  publicIp: The public IP address" << std::endl;
        std::cout << "  privateIp: The private IP address" << std::endl;
    }
}





    void add_nat(base bn){
      
        n_conf->update(bn,"rien");cout<<endl<<endl;
    }

    void get_nat(){
      base bnn;
      
      for(tab_nat_stat o : n_conf->get_all(bnn).tab_n_statique){
        cout<<o.ip_public<<" "<<o.ip_prive<<endl;
      }cout<<endl<<endl;
    }





    void showNat(const std::vector<std::string>& params) {
    
        //int id = std::stoi(params[0]);

        // Use the variable to perform the required action
        std::cout << "Showing NAT "  << std::endl;
          get_nat();
    
}

        

    // Create functions for all other commands
    // ...

    

    



   enum class Command {
    ADD_POLICY,
    SHOW_ALL_POLICY,
    ADD_RULE_IN_POLICY,
    ADD_USER,
    SHOW_USER,
    SHOW_GROUP,
    ADD_groupe,
    ADD_SESSION,
    SHOW_SESSION,
    ADD_ROUTE,
    SHOW_ROUTE,
    ADD_NAT,
    SHOW_NAT,
    SHOW_INTERFACE,
    ADD_INTERFACE,
    EXIT,
    QUIT,
    ADD_ZONE,
    SHOW_ZONE,
    HELP,
    MAN,
    UNKNOWN
};

Command command_to_enum(const std::string& command) {
    if (command == "add_policy") {
        return Command::ADD_POLICY;
    } else if (command == "show_all_policy") {
        return Command::SHOW_ALL_POLICY;
    }else if (command == "add_rule_in_policy") {
        return Command::ADD_RULE_IN_POLICY;
    }else if (command == "add_user") {
        return Command::ADD_USER;
    }else if (command == "show_user") {
        return Command::SHOW_USER;
    }else if (command == "add_groupe") {
        return Command::ADD_groupe;
    }  else if (command == "help") {
        return Command::HELP;
    } else if (command == "man") {
        return Command::MAN;
    }else if (command == "add_session") {
        return Command::ADD_SESSION;
    } else if (command == "show_session") {
        return Command::SHOW_SESSION;
    } else if (command == "add_route") {
        return Command::ADD_ROUTE;
        } else if (command == "show_route") {
        return Command::SHOW_ROUTE;
    } else if (command == "add_nat") {
        return Command::ADD_NAT;
    } else if (command == "show_nat") {
        return Command::SHOW_NAT;
    }else if (command == "show_group") {
        return Command::SHOW_GROUP;
    }  else if (command == "show_zone") {
        return Command::SHOW_ZONE;
    }  else if (command == "add_zone") {
        return Command::ADD_ZONE;
    }  else if (command == "show_interface") {
        return Command::SHOW_INTERFACE;
    } else if (command == "add_interface") {
        return Command::ADD_INTERFACE;
    } else if (command == "exit") {
        return Command::EXIT;
    }else if (command == "quit") {
        return Command::QUIT;
    }  else {
        return Command::UNKNOWN;
    }
}






 void man(const std::vector<std::string>& params) {
    if (params.size() != 1) {
        std::cout << "Invalid number of parameters for man command." << std::endl;
        std::cout << "Expected usage: man command_name" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  command_name: The name of the command for which you want to display the detailed description (NB: execute the command help to show all availables commands)" << std::endl;
        return;
    }

    Command command = command_to_enum(params[0]);

    switch (command) {
    case Command::ADD_POLICY:
        std::cout << "add_policy:" << std::endl;
        std::cout << "  Adds a new policy with the specified name." << std::endl;
        std::cout << "  Usage: add_policy policy_name" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "    policy_name: The name of the policy to be added" << std::endl;
        break;

    case Command::SHOW_ALL_POLICY:
        std::cout << "show_all_policy:" << std::endl;
        std::cout << "  Displays a list of all policies currently configured." << std::endl;
        std::cout << "  Usage: show_all_policy" << std::endl;
        std::cout << "  Parameters: None" << std::endl;
        break;

    // ... (add all the other commands here)
    case Command::ADD_RULE_IN_POLICY:
        std::cout << "add_rule_in_policy";
        std::cout << "Adds a new rule in a specific policy";
        std::cout << "  Usage: add_rule_in_policy policyName sourceZone destinationZone sourceIp destinationIp sourcePort destinationPort userName action" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "      policyName: The name of the policy to which the rule will be added." << std::endl;
        std::cout << "      sourceZone: The name of the source zone for the rule." << std::endl;
        std::cout << "      destinationZone: The name of the destination zone for the rule." << std::endl;
        std::cout << "      sourceIp: The source IP address for the rule." << std::endl;
        std::cout << "      destinationIp: The destination IP address for the rule." << std::endl;
        std::cout << "      sourcePort: The source port for the rule." << std::endl;
        std::cout << "      destinationPort: The destination port for the rule." << std::endl;
        std::cout << "      userName: The name of the user associated with the rule." << std::endl;
        std::cout << "      action: The action to be taken for the rule (ACCEPT or DROP)." << std::endl;
        break;
    
    case Command::ADD_USER:
        std::cout << "add_user:"; 
        std::cout << "  Adds a new user"; 
        std::cout << "  Parameters:" << std::endl;
        std::cout << "    group: The group of user " << std::endl;
        std::cout << "    name: The user name" << std::endl;
        break;

    case Command::ADD_groupe:
        std::cout <<"add_groupe";
        std::cout << "  Usage: add_groupe groupname " << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "     groupname: The name of group  " << std::endl;
        break;

    case Command::SHOW_USER:
        std::cout << "show_user:" << std::endl;
        std::cout << "  Displays all users." << std::endl;
        std::cout << "  Usage: show_user " << std::endl;
        std::cout << "  Parameters: None" << std::endl;
    break;

     case Command::SHOW_GROUP:
        std::cout << "show_group:" << std::endl;
        std::cout << "  Displays all GROUPS." << std::endl;
        std::cout << "  Usage: show_group " << std::endl;
        std::cout << "  Parameters: None" << std::endl;
    break;

    case Command::ADD_SESSION:
        std::cout << "add_session:" << std::endl;
        std::cout << "  Adds a new session " << std::endl;
        std::cout << "  Usage: add_session src_ip dst_ip src_port dst_port state" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "    src_ip: The source IP address of the session." << std::endl;
        std::cout << "    dst_ip: The destination IP address of the session." << std::endl;
        std::cout << "    src_port: The source port of the session." << std::endl;
        std::cout << "    dst_port: The destination port of the session." << std::endl;
        std::cout << "    state: The state of the session (e.g. ESTABLISHED, CLOSED)." << std::endl;
        break;
        

    case Command::SHOW_SESSION:
        std::cout << "show_session:" << std::endl;
        std::cout << "  Displays a list of all active sessions." << std::endl;
        std::cout << "  Usage: show_session" << std::endl;
        std::cout << "  Parameters: None" << std::endl;
        break;


    case Command::ADD_ZONE:
        std::cout << "add_zone:" << std::endl;
        std::cout << "  Adds a new zone with the specified name." << std::endl;
        std::cout << "  Usage: add_zone name" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "    name: The name of the zone to be added" << std::endl;
        break;


    case Command::SHOW_ZONE:
        std::cout << "show_zone:" << std::endl;
        std::cout << "  Displays a list of all zones currently configured." << std::endl;
        std::cout << "  Usage: show_zone" << std::endl;
        std::cout << "  Parameters: None" << std::endl;
        break;

    case Command::ADD_ROUTE:
        std::cout << "add_route:" << std::endl;
        std::cout << "  Adds a new route with the specified id, destination IP and next hop." << std::endl;
        std::cout << "  Usage: add_route id destinationIP nextHop" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "    id: The id of the route to be added." << std::endl;
        std::cout << "    destinationIP: The destination IP of the route to be added." << std::endl;
        std::cout << "    nextHop: The next hop of the route to be added." << std::endl;
        break;

    case Command::SHOW_ROUTE:
        std::cout << "show_route:" << std::endl;
        std::cout << "  Displays a list of all routes currently configured." << std::endl;
        std::cout << "  Usage: show_route" << std::endl;
        std::cout << "  Parameters: None" << std::endl;



    
    case Command::ADD_NAT:
        std::cout << "add_nat:" << std::endl;
        std::cout << "  Adds a new NAT rule with the specified public IP and private IP." << std::endl;
        std::cout << "  Usage: add_Nat publicIp privateIp" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "    publicIp: The public IP address to be used in the NAT rule." << std::endl;
        std::cout << "    privateIp: The private IP address to be used in the NAT rule." << std::endl;
        break;



    case Command::SHOW_NAT:
        std::cout << "show_nat:" << std::endl;
        std::cout << "  Displays the current NAT configuration." << std::endl;
        std::cout << "  Usage: show_nat" << std::endl;
        std::cout << "  Parameters: None" << std::endl;
        break;

    case Command::SHOW_INTERFACE:
        std::cout << "show_interface:" << std::endl;
        std::cout << " usage: showInterface id" << std::endl;
        std::cout << " Parameters:None" << std::endl;

    case Command::ADD_INTERFACE:
        std::cout << "add_interface:" << std::endl;
        std::cout << "  usage: addInterface id base inter_conf tools zone" << std::endl;
        std::cout << "  Parameters:" << std::endl;
        std::cout << "  id: The interface ID (integer)" << std::endl;
        std::cout << "  base: The base configuration" << std::endl;
        std::cout << "  inter_conf: The interface configuration" << std::endl;
        std::cout << "  tools: The tools used for the interface" << std::endl;
        std::cout << "  zone: The zone of the interface" << std::endl;
    


    case Command::HELP:
        std::cout << "help:" << std::endl;
        std::cout << "  Show a list of available commands and their brief descriptions." << std::endl;
        std::cout << "  Usage: help" << std::endl;
        std::cout << "  No parameters"<< std::endl;
        break;


    case Command::EXIT:
        std::cout << "exit:" << std::endl;
        std::cout << "  Exits the firewall application." << std::endl;
        std::cout << "  Usage: exit" << std::endl;
        std::cout << "  Parameters: None" << std::endl;
        break;


    case Command::QUIT:
        std::cout << "quit:" << std::endl;
        std::cout << "  Quit the firewall application." << std::endl;
        std::cout << "  Usage: quit" << std::endl;
        std::cout << "  Parameters: None" << std::endl;
        break;

   
    case Command::MAN:
    std::cout << "man:" << std::endl;
    std::cout << "  Show a detailed description of a specific command, including its parameters and usage." << std::endl;
    std::cout << "  Usage: man command_name" << std::endl;
    std::cout << "  Parameters:" << std::endl;
    std::cout << "    command_name: The name of the command for which you want to display the detailed description (NB: execute the command help to show all availables commands)" << std::endl;
    break;

    case Command::UNKNOWN:
    default:
    std::cout << "Unknown command. Please use 'help' to see the list of available commands." << std::endl;
    break;
}
}






void clear(const std::vector<std::string>& params) {
    // Clear the console screen
    std::cout << "\033[2J\033[1;1H";
}




static char** command_completion(const char* text, int start, int end) {
    rl_attempted_completion_over = 1; // Don't use filename completion
    return rl_completion_matches(text, command_generator);
}



static char* command_generator(const char* text, int state) {
    static std::vector<std::string> matches;
    static size_t match_index;

    if (state == 0) {
        // If this is a new word to complete, initialize now.
        // This function might return some or all the text passed.
        matches.clear();
        match_index = 0;

        // Collect a vector of matches: replace "commands" with the appropriate container of available commands
        std::vector<std::string> commands = {"add_policy", "add_rule_in_policy", "show_all_policy", "add_user", "show_user","add_groupe", "add_session", "show_session","show_group", "show_route", "add_nat", "show_nat","add_zone","show_zone","add_route" ,"show_interface ","add_interface", "quit","exit", "help", "man", "clear"};

        for (const auto& command : commands) {
            if (command.find(text) == 0) {
                matches.push_back(command);
            }
        }
    }

    if (match_index < matches.size()) {
        return strdup(matches[match_index++].c_str());
    } else {
        return nullptr; // No more matches
    }
}



 void quit(const std::vector<std::string>&) {
        
        //std::cout<<"press ctrl-c to exit";
        running = false;
    }
    



    void add_aplication(base b){    // tu lui donne url et il ajoute
      a_conf->add(b.aplication_name);
    }

    base get_application_liste(base b){  // tu lui donne base il te rend urlliste dans base
      b.domaine_veu_liste=true;
      b=a_conf->get("ss",b);
      return b;
    }



  void addSession(const std::vector<std::string>& params) {
    if (params.size() == 5) {
        std::string src_ip = params[0];
        std::string dst_ip = params[1];
        int src_port = std::stoi(params[2]);
        int dst_port = std::stoi(params[3]);
        std::string state = params[4];

        // Use the variables to perform the required action
        base b;
        b.s.src_ip=src_ip;
        b.s.dst_ip=dst_ip;
        b.s.src_port=src_port;
        b.s.dst_port=dst_port;
        b.s.state=state;
        add_session(b);
        std::cout << "Adding session with src_ip: " << src_ip << ", dst_ip: " << dst_ip << ", src_port: " << src_port
                  << ", dst_port: " << dst_port << ", state: " << state << std::endl;

    } else {
        std::cout << "Invalid number of parameters for addSession command." << std::endl;
        std::cout << "Expected usage: add_session src_ip dst_ip src_port dst_port state" << std::endl;
        std::cout << "Parameters:" << std::endl;
        std::cout << "  src_ip: The source IP address" << std::endl;
        std::cout << "  dst_ip: The destination IP address" << std::endl;
        std::cout << "  src_port: The source port (integer)" << std::endl;
        std::cout << "  dst_port: The destination port (integer)" << std::endl;
        std::cout << "  state: The session state" << std::endl;
    }
}


    void add_session(base b){
        s_conf->update(b,"rien");
    }

    base get_session(){
        base b;
        return s_conf->get_all(b);
    }

bool isNumber(const std::string& str) {
    try {
        std::stoi(str);
        return true;
    } catch (const std::invalid_argument& e) {
        return false;
    } catch (const std::out_of_range& e) {
        return false;
    }
}

  void showSession(const std::vector<std::string>& params) {
        std::cout << " sessions availables are : " <<  std::endl;
         base bb=get_session();
         for(session po : bb.tab_session){
            std::cout<<po.src_ip<<" "<<po.dst_ip<<" "<<po.src_port<<" "<<po.dst_port<<" "<<po.state<<endl;
             }
  }






    bool handle_incoming_packet(packet pac) {
         
        strategieSEC* obj=new filtrage;
        Securite_Context context;
        
        context.set_strategy(obj);
        this->j=new configuration;
       if (context.execute_strategy(pac,j, s_conf,tab)==true) {
           // printf("Packet accepted.\n");
           return true;
        }
         else {
            //printf("Packet rejected.\n");
            return false;
          }

    }



    void get_packet(){
      //printf("bdiit");

      struct pcap_pkthdr *header;
      
      int x=1;
      bool var;
     // printf("ha nadkhol");
     base bi;
     while (x<5)
     {
      
     
      for(interfaces i : i_conf->get_all(bi).tab_interfaces){
      
      packet pac;pac=i.receive(x);
      //printf("jabtouuu");
      var=handle_incoming_packet(pac);

      x++;
      if(var==true)
      {
        strategieRTG* ob=new routage_stat;
        Routage_Context cont;
        
        cont.set_strategy(ob);
        cont.execute_strategy(pac, r_conf,n_conf);
        ob=new nat;
        cont.set_strategy(ob);
        pac.src_ip=cont.execute_strategy(pac,r_conf,n_conf);
        i.send(pac);
      }
      }
      
     }
    }

    
    //void supr (string srcIP, string destIP, int srcPort, int destPort, bool permit){}
    
   







void help(const std::vector<std::string>& params) {
        // Your implementation
        
    std::cout << "Available commands:" << std::endl;
    std::cout << "  add_policy: Adds a new policy with the specified name." << std::endl;
    std::cout << "  add_rule_in_policy: Adds a new rule to an existing policy." << std::endl;
    std::cout << "  add_user: Adds a new user with the specified name." << std::endl;
    std::cout << "  add_group: Adds a new user group with the specified name." << std::endl;
    std::cout << "  add_nat: Adds a new NAT rule." << std::endl;
    std::cout << "  add_zone: Adds a new security zone." << std::endl;
    std::cout << "  add_session: Adds a new active session." << std::endl;
    std::cout << "  add_route: Adds a new routing table entry." << std::endl;
    std::cout << "  add_interface: Adds a new interface ." << std::endl;
    std::cout << "  show_all_policy: Displays a list of all policies currently configured." << std::endl;
    std::cout << "  show_user: Displays a list of all users currently configured." << std::endl;
    std::cout << "  show_group: Displays a list of all groups currently configured." << std::endl;
    std::cout << "  show_nat: Displays a list of all NAT rules currently configured." << std::endl;
    std::cout << "  show_zone: Displays a list of all security zones currently configured." << std::endl;
    std::cout << "  show_session: Displays a list of all active sessions." << std::endl;
    std::cout << "  show_route: Displays a list of all routing table entries." << std::endl;
    std::cout << "  show_interface: Displays a list of all routing table entries." << std::endl;
    std::cout << "  man: Displays the manual page for the specified command." << std::endl;
    std::cout << "  exit: Exits the application." << std::endl;
    std::cout << "  quit: Quit the application." << std::endl;
    std::cout << "  clear: Clear this console." << std::endl;
    std::cout << "  help: Displays this help message." << std::endl;
    
}

bool authenticate(const std::vector<std::string>& credentials) {
    // Implement your authentication logic here.
    // Return true if credentials are valid, false otherwise.
      std::string username = credentials[0];
    std::string password = credentials[1];

    std::ifstream file("auth.txt");
    if (!file) {
        std::cerr << "Could not open the file." << std::endl;
        return false;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::vector<std::string> file_credentials{std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};

        // Assuming that each line in the file has exactly two strings - username and password
        if (file_credentials[0] == username && file_credentials[1] == password) {
            return true; // User authenticated
        }
    }

    return false;
}

void run_cli() {
    // Command map
    std::unordered_map<std::string, std::function<void(const std::vector<std::string>&)>> command_map = {
        {"add_policy", std::bind(&Firewall::add_policy, this, std::placeholders::_1)},
        {"show_all_policy", std::bind(&Firewall::show_all_policy, this, std::placeholders::_1)},
        {"add_rule_in_policy", std::bind(&Firewall::add_rule_in_policy, this, std::placeholders::_1)},
        {"add_user", std::bind(&Firewall::addUser, this, std::placeholders::_1)},
        {"add_groupe", std::bind(&Firewall::addgroupe, this, std::placeholders::_1)},
        {"show_user", std::bind(&Firewall::showUser, this)},
        {"add_session", std::bind(&Firewall::addSession, this, std::placeholders::_1)},
        {"show_session", std::bind(&Firewall::showSession, this, std::placeholders::_1)},
        {"show_group", std::bind(&Firewall::showgroupe, this, std::placeholders::_1)},
        {"add_zone", std::bind(&Firewall::addZone, this, std::placeholders::_1)},
        {"show_zone", std::bind(&Firewall::showZone, this, std::placeholders::_1)},
        {"add_route", std::bind(&Firewall::addroute, this, std::placeholders::_1)},
        {"show_route", std::bind(&Firewall::show_route, this, std::placeholders::_1)},
        {"add_nat", std::bind(&Firewall::addNat, this, std::placeholders::_1)},
        {"show_nat", std::bind(&Firewall::showNat, this, std::placeholders::_1)},
        {"quit", std::bind(&Firewall::quit, this, std::placeholders::_1)},
        {"exit", std::bind(&Firewall::quit, this, std::placeholders::_1)},
        {"clear", std::bind(&Firewall::clear, this, std::placeholders::_1)},
        {"man", std::bind(&Firewall::man, this, std::placeholders::_1)},
        {"help", std::bind(&Firewall::help, this, std::placeholders::_1)},
        {"add_interface", std::bind(&Firewall::addInterface, this, std::placeholders::_1)},
         {"show_interface", std::bind(&Firewall::showInterface, this, std::placeholders::_1)},
    };
    rl_attempted_completion_function = command_completion;
    // Boucle de commande CLI
     std::cout << "Welcome to NGFW. Please log in." << std::endl;

    bool authenticated = false;
    while (!authenticated) {
        char* line = readline("Username: ");
        std::string username(line);
        free(line);
        line = readline("Password: ");
        std::string password(line);
        free(line);
        if (this->authenticate({username, password})) {
            authenticated = true;
            std::cout << "Login successful." << std::endl;
        } else {
            std::cout << "Invalid credentials. Please try again." << std::endl;
        }
    }

    while (running) {
        // Affiche le prompt de commande
        char* line = readline("NGFW$> ");
        if (!line) {
            // Handle EOF (Ctrl-D)
            break;
        }

        // Add the command to the history
        if (*line) {
            add_history(line);
        }

        std::string input(line);
        free(line);

        // Tokenize the input
        std::istringstream iss(input);
        std::vector<std::string> tokens{std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};

        // Check if the command is in the map
        if (!tokens.empty()) {
            auto cmd = command_map.find(tokens[0]);
            if (cmd != command_map.end()) {
                // Extract the parameters
                std::vector<std::string> params(tokens.begin() + 1, tokens.end());

                // Call the command handler
                cmd->second(params);
            } else {
                std::cout << "Command not recognized.\n";
            }
        }
    }
}


void run_interface() {
    crow::SimpleApp app;
    Firewall& firewall = Firewall::getInstance();  
 





CROW_ROUTE(app, "/script.js")
([]() {
    std::ifstream file("script.js");
    if (file) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();
        return crow::response(200, buffer.str());
    } else {
        return crow::response(404);
    }
});





CROW_ROUTE(app, "/jquery.min.js")
([]() {
    std::ifstream file("jquery.min.js");
    if (file) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();
        return crow::response(200, buffer.str());
    } else {
        return crow::response(404);
    }
});



CROW_ROUTE(app, "/all.min.css")
([]() {
    std::ifstream file("all.min.css");
    if (file) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();
        return crow::response(200, buffer.str());
    } else {
        return crow::response(404);
    }
});



CROW_ROUTE(app, "/style.css")
([]() {
    std::ifstream file("style.css");
    if (file) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();
        return crow::response(200, buffer.str());
    } else {
        return crow::response(404);
    }
});


  CROW_ROUTE(app, "/")([](){
        std::ifstream t("login.html");
        std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
        return str;
    });

   CROW_ROUTE(app, "/login").methods("POST"_method)
    ([&firewall](const crow::request& req){


        std::string body = req.body;

        // Parse the parameters from the body
        std::string username, pswd;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "username") {
                    username = value;
                } else if (key == "pswd") {
                    pswd = value;
                }
            }
        }

        if (!username.empty() && !pswd.empty()) {

             std::vector<std::string> credentials = {username, pswd};
        if(firewall.authenticate(credentials)) {
            // if the authentication is successful, redirect to firewall page
            crow::response res;
            res.code = 302;
            res.set_header("Location", "/firewall");
            return res;
        }
        else {
            
           crow::json::wvalue x;
            x["error"] = "Invalid credentials. Please try again.";
            return crow::response(x);
        }
        }


       
    });



CROW_ROUTE(app, "/firewall")
([]() {
    std::ifstream t("firewall.html");
    std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
    return str;
});

/*
CROW_ROUTE(app, "/logs")
([]() {
    std::ifstream t("logs.log");
    std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
    return str;
});*/


CROW_ROUTE(app, "/logs")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::ifstream logFile("logs.log");
        std::stringstream logStream;

        if (logFile) {
            logStream << logFile.rdbuf();
            logFile.close();
        } else {
            logStream << "Error: Unable to open logs.log";
        }

        return crow::response(200, logStream.str());
    });




 CROW_ROUTE(app, "/add_nat")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string publicIp, privateIp;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "publicIp") {
                    publicIp = value;
                } else if (key == "privateIp") {
                    privateIp = value;
                }
            }
        }

        if (!publicIp.empty() && !privateIp.empty()) {
            std::string result=firewall.addnat_inter(publicIp,privateIp);

            return crow::response(200, result);
        } else {
            return crow::response(400, "Invalid request.");
        }
    });


    



    CROW_ROUTE(app, "/show_nat")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::string result = firewall.get_all_nat();

        return crow::response(200, result);
    });
    


    

     CROW_ROUTE(app, "/show_interfaces")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::string result = firewall.get_all_interface();

        return crow::response(200, result);
    });
     

    CROW_ROUTE(app, "/show_routes")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::string result = firewall.get_all_routes();

        return crow::response(200, result);
    });
    
         CROW_ROUTE(app, "/add_route")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string destionationIP, nexthop;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "destionationIP") {
                    destionationIP = value;
                } else if (key == "nexthop") {
                    nexthop = value;
                }
            }
        }

        if (!destionationIP.empty() && !nexthop.empty()) {
            std:: string result =firewall.addroute_inter(destionationIP,nexthop);

            return crow::response(200, result);
        } else {
            return crow::response(400, "Invalid request.");
        }
    });
        

    CROW_ROUTE(app, "/add_rule_in_policy")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string policy_name;
        std::string source_zone;
        std::string destination_zone;
        std::string srcIP;
        std::string destIP;
        std::string srcPort;
        std::string destPort;
        std::string user_name;
        std::string Action;
        std::stringstream ss(body);
        std::string token;

        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "policy_name") {
                    policy_name = value;
                }else if (key == "source_zone") {
                    source_zone = value;
                } else if (key == "destination_zone") {
                    destination_zone = value;
                } else if (key == "srcIP") {
                    srcIP = value;
                } else if (key == "destIP") {
                    destIP = value;
                }else if (key == "srcPort") {
                    srcPort = value;
                } else if (key == "destPort") {
                    destPort = value;
                } else if (key == "user_name") {
                    user_name = value;
                } else if (key == "Action") {
                    Action = value;
                }   

            }
        }

        if (!policy_name.empty() && !source_zone.empty() && !destination_zone.empty() && !srcIP.empty()&&!destIP.empty()&& !srcPort.empty()&& !destPort.empty()&& !user_name.empty() && !Action.empty()) {
            base b;
            b.rul.src_zo=source_zone;
            b.rul.dst_zo=destination_zone;
            b.rul.srcIP=srcIP;
            b.rul.destIP=destIP;
            b.rul.srcPort=std::stoi(srcPort);
            b.rul.destPort=std::stoi(destPort);
            b.rul.us.name=user_name;
            if(Action=="permitted")
            {
            b.rul.permit=true;
            }else if(Action=="Denied")b.rul.permit=false;
            b.name_policy=policy_name;
            firewall.add_rule(b);

            return crow::response(200,  "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>");
        } else {
            return crow::response(400, "Invalid request.");
        }
    });
        
    








 CROW_ROUTE(app, "/add_interface")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string existfile, paquet_file,interfaceIP,zone;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "existfile") {
                    existfile = value;
                } else if (key == "paquet_file") {
                    paquet_file = value;
                }else if (key == "interfaceIP") {
                    interfaceIP = value;
                }else if (key == "zone") {
                    zone = value;
                }
            }
        }

        if (!existfile.empty() && !paquet_file.empty()&& !interfaceIP.empty()&& !zone.empty()) {
            std:: string result =firewall.addInterface_inter(existfile,paquet_file,interfaceIP,zone);

            return crow::response(200, "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>");
        } else {
            return crow::response(400, "Invalid request");
        }
    });






     


    CROW_ROUTE(app, "/add_session")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string ipSrc;
        std::string ipDst;
        std::string portSrc;
        std::string portDst;
        std::string Action;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "ipSrc") {
                    ipSrc = value;
                }else if (key == "ipDst") {
                    ipDst = value;
                } else if (key == "portSrc") {
                    portSrc = value;
                } else if (key == "portDst") {
                    portDst = value;
                } else if (key == "Action") {
                    Action = value;
                }  

            }
        }

        if (!ipSrc.empty() && !ipDst.empty() && !portSrc.empty() && !portDst.empty() ) {
            base b;
            b.s.src_ip=ipSrc;
            b.s.dst_ip=ipDst;
            b.s.src_port=std::stoi(portSrc);
            b.s.dst_port=std::stoi(portDst);
            b.s.state=Action;
            firewall.add_session(b);

            return crow::response(200,  "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>");
        } else {
            return crow::response(400, "Invalid request.");
        }
    });

    CROW_ROUTE(app, "/add_policy")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        auto policy_name = req.body;
        if (!policy_name.empty()) {
            std::string result = firewall.add_policy_inter(policy_name);

            return crow::response(200, result);
        } else {
            return crow::response(400, "Invalid request.");
        }
    });

/*    CROW_ROUTE(app, "/show_all_policies")
    .methods("GET"_method)
    ([&firewall]() {
        std::string result = firewall.get_all_policies();

        return crow::response(200, result);
    });*/


    CROW_ROUTE(app, "/show_all_policies")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Process the request and get the form data if necessary

        std::string result = firewall.get_all_policies();

        return crow::response(200, result);
    });



    CROW_ROUTE(app, "/show_rule")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Process the request and get the form data if necessary

        std::string result = firewall.get_all_rules();

        return crow::response(200, result);
    });








    CROW_ROUTE(app, "/show_sessions")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::string result = firewall.showSession_inter();

        return crow::response(200, result);
    });

    


    CROW_ROUTE(app, "/add_user")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string group_name, user_name;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "group_named") {
                    group_name = value;
                } else if (key == "user_named") {
                    user_name = value;
                }
            }
        }

        if (!group_name.empty() && !user_name.empty()) {
              firewall.addUserint(user_name,group_name);
             //   return crow::response(200, group_name +" "+user_name);
            return crow::response(200, "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>");
        } else {
            return crow::response(400, "<script>window.history.back();");
        }
    });




    CROW_ROUTE(app, "/addgrp")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        // Get the raw body of the request
        std::string body = req.body;

        // Parse the parameters from the body
        std::string group_name;
        std::stringstream ss(body);
        std::string token;
        while (std::getline(ss, token, '&')) {
            std::istringstream iss(token);
            std::string key, value;
            if (std::getline(std::getline(iss, key, '='), value)) {
                if (key == "addgrp") {
                    group_name = value;
                } 
            }
        }

        if (!group_name.empty() ) {
            firewall.addgroupeint(group_name);
           // std::string a="<script>window.history.back() ;alert('`Group with name: ";
           // std::string b=" has been added successfully.');</script>";
           // std::string result = a + group_name +b;

            return crow::response(200, "<script>window.history.back();</script>");
        } else {
            return crow::response(400, "<script>window.history.back();");
        }
    });

    CROW_ROUTE(app, "/show_all_users")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::string result = firewall.get_all_users();

        return crow::response(200, result);
    });



    


 CROW_ROUTE(app, "/show_all_groups")
    .methods("POST"_method)
    ([&firewall](const crow::request& req) {
        std::string result = firewall.get_all_groups();

        return crow::response(200, result);
    });


    CROW_ROUTE(app, "/css/<string>")
([](const crow::request& req, std::string css_filename) {
    std::string css_file_path = "css/" + css_filename;
    // Replace with the actual path to your CSS files directory

    // Read the CSS file content
    std::ifstream css_file(css_file_path);
    std::string css_content((std::istreambuf_iterator<char>(css_file)), std::istreambuf_iterator<char>());

    // Return the CSS content as a response
    crow::response response(css_content);
    response.set_header("Content-Type", "text/css");
    return response;
});


CROW_ROUTE(app, "/im1.png")
    ([]() {
        std::string imagePath = "im1.png"; // Change this to the correct path
        std::ifstream file(imagePath, std::ios::in | std::ios::binary);

        if (file) {
            std::string fileContent((std::istreambuf_iterator<char>(file)), (std::istreambuf_iterator<char>()));
            crow::response response(fileContent);
            response.set_header("Content-Type", "image/png");
            return response;
        } else {
            return crow::response(404);
        }
    });






    app.port(8080).multithreaded().run();
}



std::string add_policy_inter(const std::string& input) {
    std::string name;
    if (input.find("policy_name=") == 0) {
        name = input.substr(12);
    } else {
        name = input;
    }
    base  b;
    b.name_policy=name;
    this->addd_policy(b);
    //return name;
   return "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>";

    //std::ostringstream output_stream;
   // output_stream << "Adding policy with name: " << name << std::endl;

    //return output_stream.str();
}

std::string get_all_policies() {
    std::ostringstream output_stream;
    base b;
    for(Policy pp: j->get_all(b).polit){
        output_stream << pp.name << " ";
    }
    return output_stream.str();
}




std::string get_all_rules() {
    std::ostringstream output_stream;
    base b;
    for(Policy pp: j->get_all(b).polit){
      
       
        for(Rule r : pp.rules){
          output_stream<<pp.name<<" "<< r.src_zo<<" " << r.dst_zo<<" "<<r.srcIP<<" "<<r.destIP<<" "<<r.srcPort<<" "<<r.destPort<<" "<<r.us.name<<" "<<r.permit<<" "<<endl;
        }
      }
    return output_stream.str();
}







/*
void addUser_inter(const std::string& input1,const std::string& input2) {
    
        string u_name = input1;
        string g_name = input2;
        add_user_in_group(u_name,g_name);
       return ;
       //return u_name+g_name;
}
*/

void addgroupe_inter( const std::string groupname) {
        base b;b.user_groupe_name=groupname;
        add_user_groupe(b);
        return ;
    }










 std::string get_all_users(){
        base b;
          std::ostringstream output_stream;
            for(user ub : u_conf->get_all(b).tab_use)
            {   
                output_stream<<ub.name <<" "<<ub.group<<" ";
                
            }return output_stream.str();
         
    }


 std ::string  zama(){
        base b;
          std::ostringstream output_stream;
            for(user ub : u_conf->get_all(b).tab_use)
            {   if(!ub.name.empty() && !ub.group.empty())
                output_stream<<ub.name <<" "<<ub.group<<" "<<endl;
                
            }return output_stream.str();
         
    }




std::string showSession_inter() {
    std::ostringstream output_stream;
         base bb=get_session();
         for(session po : bb.tab_session){
            
            output_stream<<po.src_ip<<" "<<po.dst_ip<<" "<<po.src_port<<" "<<po.dst_port<<" "<<po.state<<" "<<endl;
             }
             return output_stream.str();
             
  }


std::string  addroute_inter(const std::string publicIp,const std::string privateIp ) {
        base br;
        br.r_statique.adr_dest=publicIp;
        br.r_statique.next_hop=privateIp;
        // Use the variables to perform the required action
        std::cout << "Adding route  "  << ", destinationIp: " << publicIp << ", next_hop: " << privateIp << std::endl;
        add_route(br);
        //return "add route was succesfully";
        return "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>";
   
}


std::string get_all_routes(){
      base brr;
    std::ostringstream output_stream;

        for(tab_stat rt : r_conf->get_all(brr).tab_r_statique){
            output_stream << rt.adr_dest<<" "<<rt.next_hop<<" "<<endl;
            
        }return output_stream.str();
    }


std::string  addnat_inter(const std::string publicIp,const std::string privateIp ) {
        base br;
        br.r_statique.adr_dest=publicIp;
        br.r_statique.next_hop=privateIp;
        base bn;
        bn.n_statique.ip_public=publicIp;
        bn.n_statique.ip_prive=privateIp;
        add_nat(bn);    
        return "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>";
}

std::string get_all_nat(){
      base bnn;
    std::ostringstream output_stream;

        for(tab_nat_stat o : n_conf->get_all(bnn).tab_n_statique){
            output_stream << o.ip_prive<<" "<<o.ip_public<<" "<<endl;
            
        }return output_stream.str();
    }



std::string addInterface_inter(std::string file ,std::string out,std::string ip,std::string zone) {
    
        
       
       const char* file2=file.c_str();
        const char* out2=out.c_str();

        // Use the variables to perform the required action
       // std::cout << "Adding interfaces: " <<ip<<endl;
        interfaces i(file2,out2,ip,zone);
        add_interface(i);
        return "<script>window.history.back();window.onunload = function() {localStorage.setItem('submitFormOnLoad', 'true');};</script>";

  
}







  

};