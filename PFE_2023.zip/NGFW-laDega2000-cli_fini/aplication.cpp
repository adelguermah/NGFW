#include "aplication.h"

aplication::aplication(std::string name){
    this->name=name;
}

aplication::aplication(){
    
}