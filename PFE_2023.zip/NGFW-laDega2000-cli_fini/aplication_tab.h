#ifndef APLICATION_TAB_H
#define APLICATION_TAB_H
#include <vector>
#include <string>
#include "aplication.h"
class aplication_tab
{

public:
    std::vector<aplication> app_tab;
    aplication_tab(/* args */);
    
};

#endif
