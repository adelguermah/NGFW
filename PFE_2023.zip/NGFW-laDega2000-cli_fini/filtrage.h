#ifndef FILTRAGE_H
#define FILTRAGE_H
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/ether.h>
#include <pcap.h>
#include "strategieSEC.h"
#include "tabses.h"
#include "session.h"
#include "filtrage.h"
#include "monitoring.h"
#include "tabdomain.h"
#include "tools.h"
class filtrage : public strategieSEC {
public:
    filtrage();
    strategieSEC* get_strategy();
    bool execute( packet pac, inter_conf* p,inter_conf* s,tabdomain& tab) override;
};

#endif // FILTRAGE_H