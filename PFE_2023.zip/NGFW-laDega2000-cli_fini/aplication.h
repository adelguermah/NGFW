#ifndef APLICATION_H
#define APLICATION_H
#include <vector>
#include <string>
class aplication
{
 public:
 std::string name;
 aplication();
 aplication(std::string);
};

#endif