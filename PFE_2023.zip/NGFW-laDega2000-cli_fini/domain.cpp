#include "domain.h"


   domain::domain(std::string domaine){
        dom=domaine;
    }
   domain::domain(){
    
   }
    





