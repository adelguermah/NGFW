class security
{
private:
    /* data */
public:
    security(/* args */);
    ~security();
};

security::security(/* args */)
{
}

security::~security()
{
}
