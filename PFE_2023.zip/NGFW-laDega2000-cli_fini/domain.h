#ifndef DOMAIN_H_
#define DOMAIN_H_
#include <string>
class domain
{

public:
    std::string dom;
    domain(std::string domaine);
    domain();
    
    
};

#endif // _MY_HEADER_H_