

/*
window.onload = function() {
  const shouldSubmitForm = localStorage.getItem('submitFormOnLoad');

  if (shouldSubmitForm === 'true') {
    localStorage.removeItem('submitFormOnLoad'); // Clear the flag

    const form = document.getElementById('your-form-id'); // Replace 'your-form-id' with the actual ID of the form
    form.submit();
  }
};*/











function submitBothFormsgroup() {
  submitFormogroup(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitFormgroup, 100);
  });
}

function submitFormogroup(callback) {
  // Get the add_policy form
  const addPolicyForm = document.getElementById('add-group-form');
  
  // Submit the add_policy form
  addPolicyForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}










function submitFormgroup() {
  // Get the form data
  const form = document.getElementById('groupform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_all_groups', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const groups = this.responseText.split(' ');
     
      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>Group name</th><th>Delete</th><th>Update</th></tr>';
      const groupSelect = document.getElementById('group_named');
      groupSelect.innerHTML = '';
     for (let i = 0; i < groups.length -1 ; i++) {
        if (groups[i].length > 0) {
          let ID = parseInt(i+1);
        const group = groups[i];
        table += `<tr>
          <td>${ID}</td>
          <td>${groups[i]}</td>
          <td><button class="delete-button"  onclick="deleteUser('${ID}')">Delete</button></td>
          <td><button class="update-button" onclick="updateUser('${ID}')">Update</button></td>
        </tr>`;

          const option = document.createElement('option');
          option.value = group;
          option.textContent = group;
          groupSelect.appendChild(option);

  }
  }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-groups');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
  
}






function submitBothFormsuser() {
  submitFormouser(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitFormuser, 100);
  });
}

function submitFormouser(callback) {
  // Get the add_policy form
  const addPolicyForm = document.getElementById('add-user-form');
  
  // Submit the add_policy form
  addPolicyForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}














function submitFormuser() {
  // Get the form data
  const form = document.getElementById('userform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_all_users', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const users = this.responseText.split(' ');

      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>User</th><th>Group</th><th>Delete</th><th>Update</th></tr>';
      const userSelect = document.getElementById('user_namep');
      userSelect.innerHTML = '';
     for (let i = 0; i < users.length -1 ; i=i+2) {
        if (users[i].length > 0) {
          let ID = parseInt(i/2 +1);
    const user = users[i];
    const group = users[i+1];
    table += `<tr>
      <td>${ID}</td>
      <td>${user}</td>
      <td>${group}</td>
      <td><button class="delete-button" onclick="deleteUser('${ID}')">Delete</button></td>
      <td><button class="update-button" onclick="updateUser('${ID}')">Update</button></td>
      </tr>`;

          const option = document.createElement('option');
          option.value = user;
          option.textContent = user;
          userSelect.appendChild(option);

   }
   }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-users');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
  
}









    function onLoad() {
    showContent('Interface-Manager');
    submitForm2();
    submitFormuser();
    submitFormSession();
    submitFormRule();
    submitFormNat();
    submitlogs();
    submitFormroutage();
    submitFormgroup();
    submitForminterface();

    const firstContentId = "Interface-Manager";
  
  // Show the first content section
  showContent(firstContentId, null);
  
  // Set the first link as active
  const firstNavbarLink = document.querySelector(".vertical-navbar a");
  firstNavbarLink.classList.add("active");
    

  }

  // Call the onLoad function when the window loads
  window.onload = onLoad;


  function showContent(contentId, event = null) {
  // Hide all content sections
  const contentSections = document.getElementsByClassName("content-section");
  for (let i = 0; i < contentSections.length; i++) {
    contentSections[i].style.display = "none";
  }

  // Show the selected content section
  const content = document.getElementById(contentId);
  content.style.display = "block";

  // Remove the active class from all navbar links
  const navbarLinks = document.querySelectorAll(".vertical-navbar a");
  for (let i = 0; i < navbarLinks.length; i++) {
    navbarLinks[i].classList.remove("active");
  }

  // Add the active class to the clicked navbar link
  if (event) {
    event.target.classList.add("active");
  }
}









function deletePolicy(policy) {
  // Implement your delete policy logic here
  console.log('Delete policy:', policy);
}


function deleteUser(User) {
  // Implement your delete policy logic here
  console.log('Delete User:', User);
}

function updatePolicy(policy) {
  // Implement your update policy logic here
  console.log('Update policy:', policy);
}

function updateUser(User) {
  // Implement your update policy logic here
  console.log('Update User:', User);
}



function deleteRoute(route) {
  // Implement your delete route logic here
  console.log('Delete route:', route);
}
function updateRoute(route) {
  // Implement your update route logic here
  console.log('Update route:', route);
}


function deleteNat(nat) {
  // Implement your delete nat logic here
  console.log('Delete nat:', nat);
}
function updateNat(nat) {
  // Implement your update nat logic here
  console.log('Update nat:', nat);
}






function submitFormo2(callback) {
  // Get the add_policy form
  const addPolicyForm = document.getElementById('add-policy-form');

// Submit the add_policy form
addPolicyForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}


function submitBothForms2() {
  submitFormo2(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitForm2, 100);
  });
}


function submitForm2() {
  // Get the form data
  const form = document.getElementById('my-form');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_all_policies', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const policies = this.responseText.split(' ');

      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>Policy</th><th>Delete</th><th>Update</th></tr>';

      // Populate the policy_name <select> tag in the first form
      const policySelect = document.getElementById('policy_namepp');
      policySelect.innerHTML = '';

      for (let i = 0; i < policies.length - 1; i++) {
        if (policies[i].length > 0) {
          const policy = policies[i];
          let ID = parseInt((i / 2) + 1);
          table += `<tr>
            <td>${ID}</td>
            <td>${policy}</td>
            <td><button class="delete-button" onclick="deletePolicy('${ID}')">Delete</button></td>
            <td><button class="update-button" onclick="updatePolicy('${ID}')">Update</button></td>
          </tr>`;

          // Add an option for the policy_name <select> tag
          const option = document.createElement('option');
          option.value = policy;
          option.textContent = policy;
          policySelect.appendChild(option);
        }
      }

      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-container');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
}












function submitlogs() {
  // Get the form data
  const form = document.getElementById('formlogs');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/logs', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned log lines
      const logLines = this.responseText.split('\n');
      const logs = [];

      for (let i = 0; i < logLines.length; i += 2) {
        const line1 = logLines[i];
        const line2 = logLines[i + 1];

        if (line1.trim() === "" || line2.trim() === "") continue; // Ignore empty lines

        const date = line1.substr(0, 24);
        const warning = line2.substr(1, 10);
        const message = line2.substr(12);

        const srcIPMatch = message.match(/Source IP: (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/);
        const dstIPMatch = message.match(/Destination IP: (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/);

        const srcIP = srcIPMatch ? srcIPMatch[1] : "N/A";
        const dstIP = dstIPMatch ? dstIPMatch[1] : "N/A";

        logs.push({ date, warning, message, srcIP, dstIP });
      }

      // Create a table with the parsed data
      let tableHTML = '<table><tr><th>Date</th><th>Warning</th><th>Paquet Rejeter</th><th>Src IP</th><th>Dst IP</th></tr>';
      for (const log of logs) {
        tableHTML += `<tr><td>${log.date}</td><td>${log.warning}</td><td>${log.message}</td><td>${log.srcIP}</td><td>${log.dstIP}</td></tr>`;
        
      }
      tableHTML += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-logs');
      resultContainer.innerHTML = tableHTML;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
}


















function submitFormoroutage(callback) {
  // Get the add_policy form
  const addRoutageForm = document.getElementById('add-routage-form');

// Submit the add_policy form
addRoutageForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}


function submitBothFormsroutage() {
  submitFormoroutage(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitFormroutage, 100);
  });
}


function submitFormroutage() {
  // Get the form data
  const form = document.getElementById('routageform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_routes', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const routes = this.responseText.split(' ');

      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>destination</th><th>next hop</th><th>Delete</th><th>Update</th></tr>';
     for (let i = 0; i < routes.length -1 ; i=i+2) {
        if (routes[i].length > 0) {
  const publicIp = routes[i];
  const privateIP = routes[i+1];
  let ID = parseInt((i/2)+1);
  table += `<tr>
    <td>${ID}</td>
    <td>${publicIp}</td>
    <td>${privateIP}</td>
    <td><button class="delete-button" onclick="deleteRoute('${ID}')">Delete</button></td>
    <td><button class="update-button" onclick="updateRoute('${ID}')">Update</button></td>
  </tr>`;}
 }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-route');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
}








function validateFormAndSubmitnat() {
    const publicIp = document.getElementById("publicIp");
    const privateIp = document.getElementById("privateIp");

    // Validate the form
    if (publicIp.checkValidity() && privateIp.checkValidity()) {
        submitBothFormsnat(); // You can change this function name based on your implementation
    } else {
        // Show error message or perform any other action
    }

    // Return false to prevent the default form submission
    return false;
}













function submitFormonat(callback) {
  // Get the add_policy form
  const addNatForm = document.getElementById('add-nat-form');

  // Submit the add_policy form
  addNatForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}


function submitBothFormsnat() {
  submitFormonat(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitFormNat, 100);
  });
}


function submitFormNat() {
  // Get the form data
  const form = document.getElementById('natform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_nat', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const nats = this.responseText.split(' ');

      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>publicIp</th><th>privateIP</th><th>Delete</th><th>Update</th></tr>';
     for (let i = 0; i < nats.length -1 ; i=i+2) {
        if (nats[i].length > 0) {
  const publicIp = nats[i];
  const privateIP = nats[i+1];
  let ID = parseInt((i/2)+1);
  table += `<tr>
    <td>${ID}</td>
    <td>${privateIP}</td>
    <td>${publicIp}</td>
    <td><button class="delete-button" onclick="deleteNat('${ID}')">Delete</button></td>
    <td><button class="update-button" onclick="updateNat('${ID}')">Update</button></td>
  </tr>`;}
 }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-nat');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
}













function submitFormosession(callback) {
  // Get the add_policy form
  const addsessionForm = document.getElementById('add-session-form');

  // Submit the add_policy form
  addsessionForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}


function submitBothFormssession() {
  submitFormosession(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitFormSession, 100);
  });
}


function submitFormSession() {
  // Get the form data
  const form = document.getElementById('sessionform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_sessions', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const sessions = this.responseText.split(' ');

      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>ipSource</th><th>ipDestination</th><th>portSource</th><th>portDestination</th><th>action</th><th>Delete</th><th>Update</th></tr>';
     for (let i = 0; i < sessions.length -1 ; i=i+5) {
        if (sessions[i].length > 0) {
  const ID= parseInt(i/5 +1);
  const ipSource = sessions[i];
  const ipDestination = sessions[i+1];
  const portSource = sessions[i+2];
  const portDestination = sessions[i+3];
  const action = sessions[i+4];
  
  table += `<tr>
    <td>${ID}</td>
    <td>${ipSource}</td>
    <td>${ipDestination}</td>
    <td>${portSource}</td>
    <td>${portDestination}</td>
    <td>${action}</td>
    <td><button class="delete-button" onclick="deleteNat('${ID}')">Delete</button></td>
    <td><button class="update-button" onclick="updateNat('${ID}')">Update</button></td>
  </tr>`;}
 }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-session');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
}
















function submitFormorule(callback) {
  // Get the add_policy form
  const addsessionForm = document.getElementById('add-rule-form');

  // Submit the add_policy form
  addsessionForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}



function submitBothFormsrule() {
  submitFormorule(() => {
    // Use setTimeout to add a delay before calling submitFormRule
    setTimeout(submitFormRule, 100);
  });
}





function submitFormRule() {
  // Get the form data
  const form = document.getElementById('ruleform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_rule', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const rules = this.responseText.split(' ');

      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>policy name</th><th>source zone</th><th>destination zone</th><th>ipSource</th><th>ipDestination</th><th>portSource</th><th>portDestination</th><th>username</th><th>action</th><th>Delete</th><th>Update</th></tr>';
     for (let i = 0; i < rules.length -2 ; i=i+9) {
        if (rules[i].length > 0) {
  const ID= parseInt(i/10 +1);
  const policyname = rules[i];
  const srczone = rules[i+1];
  const dstzone = rules[i+2];
  const ipSource = rules[i+3];
  const ipDestination = rules[i+4];
  const portSource = rules[i+5];
  const portDestination = rules[i+6];
  const user = rules[i+7];
  const action = rules[i+8];
  
  table += `<tr>
    <td>${ID}</td>
    <td>${policyname}</td>
    <td>${srczone}</td>
    <td>${dstzone}</td>
    <td>${ipSource}</td>
    <td>${ipDestination}</td>
    <td>${portSource}</td>
    <td>${portDestination}</td>
    <td>${user}</td>
    <td>${action}</td>
    <td><button class="delete-button" onclick="deleteNat('${ID}')">Delete</button></td>
    <td><button class="update-button" onclick="updateNat('${ID}')">Update</button></td>
  </tr>`;}
 }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-rules');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
}









document.addEventListener("DOMContentLoaded", function () {
    const navLinks = document.querySelectorAll(".nav-link");

    navLinks.forEach(link => {
        link.addEventListener("click", event => {
            navLinks.forEach(el => el.classList.remove("active"));
            event.target.classList.add("active");
        });
    });
});




function toggleDarkMode() {
    const currentMode = localStorage.getItem('mode');
    const toggleButton = document.getElementById('toggle-dark-mode');
    
    if (currentMode === 'dark') {
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('mode', 'light');
        toggleButton.textContent = 'Switch to Dark Mode';
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('mode', 'dark');
        toggleButton.textContent = 'Switch to Light Mode';
    }
    updateStylesheet();
}

function updateStylesheet() {
    const currentMode = localStorage.getItem('mode');
    const stylesheet = document.getElementById('theme-stylesheet');
    if (currentMode === 'light') {
        stylesheet.href = '/css/light-mode.css';
    } else {
        stylesheet.href = '/css/dark-mode.css';
    }
}

// Set the initial theme based on localStorage or default to dark mode
if (!localStorage.getItem('mode')) {
    localStorage.setItem('mode', 'dark');
}
updateStylesheet();



/*

function validateFormAndSubmit() {
    const srcIP = document.getElementById("srcIP");
    const destIP = document.getElementById("destIP");
    const pattern = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])$/;

    if (!pattern.test(srcIP.value)) {
        alert("Please enter a valid IPv4 address for srcIP");
        return false;
    } else if (!pattern.test(destIP.value)) {
        alert("Please enter a valid IPv4 address for destIP");
        return false;
    } else {
        submitBothFormsrule();
    }
}*/


function validateFormAndSubmit() {
    const destIP = document.getElementById("destIP");
    const pattern = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])$/;

    if (!pattern.test(destIP.value)) {
        alert("Please enter a valid IPv4 address");
        return false;
    } else {
        submitBothFormsrule();
    }
  }


function validateFormAndSubmitRoutage() {
    const publicIp = document.getElementById("destionationIP");
    const privateIp = document.getElementById("nexthop");

    // Validate the form
    if (publicIp.checkValidity() && privateIp.checkValidity()) {
        submitBothFormsroutage();
    } else {
        // Show error message or perform any other action
    }

    // Return false to prevent the default form submission
    return false;
}








function validateIP(ip) {
    const ipPattern = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])$/;
    return ipPattern.test(ip.value);
}




function validateFormAndSubmitSession() {
    const ipSrc = document.getElementById("ipSrc");
    const ipDst = document.getElementById("ipDst");
    const portSrc = document.getElementById("portSrc");
    const portDst = document.getElementById("portDst");
    const action = document.getElementById("Action");

    if (!validateIP(ipSrc)) {
        alert("Please enter a valid IPv4 address for ipSrc.");
        return false;
    }

    if (!validateIP(ipDst)) {
        alert("Please enter a valid IPv4 address for ipDst.");
        return false;
    }

    if (ipSrc.checkValidity() && ipDst.checkValidity() && portSrc.checkValidity() && portDst.checkValidity() && action.checkValidity()) {
        // Call the submitBothFormssession function
        submitBothFormssession();

        // Return false to prevent the default form submission behavior
        return false;
    } else {
        // Show error message or perform any other action
        alert('Please fill in all required fields.');
        return false;
    }
}































function submitBothFormsinterface() {
  submitFormointerface(() => {
    // Use setTimeout to add a delay before calling submitForm2
    setTimeout(submitForminterface, 100);
  });
}

function submitFormointerface(callback) {
  // Get the add_policy form
  const addPolicyForm = document.getElementById('add-interface-form');
  
  // Submit the add_policy form
  addPolicyForm.submit();
  // Add your form submission logic here

  // Call the callback function after the form submission is complete
  if (typeof callback === 'function') {
    callback();
  }
}






function submitForminterface() {
  // Get the form data
  const form = document.getElementById('interfaceform');
  const formData = new FormData(form);

  // Create an AJAX request
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/show_interfaces', true);
  xhr.onload = function () {
    if (this.status === 200) {
      // Parse the returned policies
      const groups = this.responseText.split(' ');
     
      // Create a table with delete and update buttons
      let table = '<table border="1">';
      table += '<tr><th>ID</th><th>Adresse ip</th><th>Zone</th><th>Delete</th><th>Update</th></tr>';
      
     for (let i = 0; i < groups.length -1 ; i=i+2) {
        if (groups[i].length > 0) {
          let ID = parseInt(i/2 +1);
        const adresseip = groups[i];
        const Zone = groups[i+1];
        table += `<tr>
          <td>${ID}</td>
          <td>${adresseip}</td>
          <td>${Zone}</td>
          <td><button class="delete-button"  onclick="deleteUser('${ID}')">Delete</button></td>
          <td><button class="update-button" onclick="updateUser('${ID}')">Update</button></td>
        </tr>`;

         

  }
  }
      table += '</table>';

      // Update the content of the result-container div
      const resultContainer = document.getElementById('result-interface');
      resultContainer.innerHTML = table;
    } else {
      console.error('AJAX request failed:', this.status, this.statusText);
    }
  };

  // Send the AJAX request
  xhr.send(formData);
  
}



function validateFormAndSubmitInterface() {
  const interfaceIP = document.getElementById("interfaceIP");

  // Validate the form
  if (interfaceIP.checkValidity()) {
    submitBothFormsinterface(); // You can change this function name based on your implementation
  } else {
      // Show error message or perform any other action
  }

  // Return false to prevent the default form submission
  return false;
}

