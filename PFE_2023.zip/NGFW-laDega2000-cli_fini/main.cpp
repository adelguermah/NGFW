#include <iostream>
#include <vector>
#include <string>
#include "Firewall.cpp"



int main(int argc, char *argv[]) {
    // Create the firewall object
    Firewall& firewall = Firewall::getInstance();
//  firewall.display_loading_message("modules of NGFW...");

    // Run the CLI in a separate thread

   //std::thread paquetFilter_thread(&Firewall::get_packet, &firewall);
   std::thread packet_filter_thread_(&Firewall::get_packet, &firewall); 
   std::thread interface_thread(&Firewall::run_interface, &firewall);
    //std::cout<<endl<<endl<<"press enter to get configuration ";
    //getchar();
    //std::cout<<endl<<endl;
    std::thread cli_thread(&Firewall::run_cli, &firewall);
    // Wait for the CLI thread to finish
   packet_filter_thread_.join();
    //paquetFilter_thread.join();
    cli_thread.join();
    interface_thread.join();
    return 0;
}