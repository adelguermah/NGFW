to compile this project use this command :
gcc -o NGFW main.cpp -lpcap -std=c++11 -lstdc++ -ltins -x c++ tabses.h tabses.cpp session.h session.cpp Rule.h Rule.cpp Securite_Context.h Securite_Context.cpp Policy.h Policy.cpp strategieSEC.h filtrage.h filtrage.cpp Log.h Log.cpp monitoring.h monitoring.cpp Firewall.cpp  tools.h tools.cpp tabdomain.h tabdomain.cpp domain.cpp interfaces.h interfaces.cpp strategieRTG.h Routage_Context.h Routage_Context.cpp zone.h zone.cpp routage_stat.h routage_stat.cpp nat.h nat.cpp configuration.h configuration.cpp inter_conf.h packet.h packet.cpp base.h base.cpp user.h user.cpp groupe.h groupe.cpp user_conf.h user_conf.cpp session_conf.h session_conf.cpp url_conf.h url_conf.cpp aplication.h aplication.cpp zone_conf.h zone_conf.cpp route_conf.h route_conf.cpp nat_conf.h nat_conf.cpp in_conf.h in_conf.cpp -lpcap -lpthread -lreadline

after that use this command :  
./NGFW 
to execute the project
