#include <iostream>
#include <string>
#include "Firewall.cpp"
Firewall& firewall = Firewall::getInstance();  

std::string add_policy_new(const std::string& input) {
    std::string name;
    if (input.find("policy_name=") == 0) {
        name = input.substr(12);
    } else {
        name = input;
    }
    base  b;
    b.name_policy=name;
    firewall.addd_policy(b);
    return name;
    //std::ostringstream output_stream;
   // output_stream << "Adding policy with name: " << name << std::endl;

    //return output_stream.str();
}


std::string get_all_policies() {
    std::ostringstream output_stream;
    base b;
    for(Policy pp: j->get_all(b).polit){
        output_stream << pp.name << std::endl;
    }
    return output_stream.str();
}
