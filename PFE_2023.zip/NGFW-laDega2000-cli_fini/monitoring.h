#include <string>
#include "Log.h"
class monitoring
{

public:
    monitoring();
    void set_log(std::string type,std::string msg);
};


